def handleTimerEvent():
	Totalizador.actualizar()
	Tanque.actualizar()