def actualizar():
	base = "[default]LACT_Bateria_1/"
	system.util.getLogger("Totalizador").debug("tick")

	valores = system.tag.readBlocking([
		base + "Volumen_Acumulado",
		base + "Caudal_Neto",
		base + "Bomba_Marcha",
		base + "Valvula_Desviadora"
	])
	volumen, caudal_neto, bomba, entregando = [v.value for v in valores]

	if volumen is not None and caudal_neto is not None:
		DT = 1.0  # segundos, igual que el timer

		# Solo suma lo que se entrega al oleoducto
		if bomba and entregando:
			volumen += caudal_neto / 3600.0 * DT   # m3/h -> m3 en este segundo
			system.tag.writeBlocking([base + "Volumen_Acumulado"], [round(volumen, 3)])